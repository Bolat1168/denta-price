npm run dev
pause