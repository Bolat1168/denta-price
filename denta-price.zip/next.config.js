/** @type {import('next').NextConfig} */
const WebpackObfuscator = require('webpack-obfuscator');

const nextConfig = {
  reactStrictMode: true,
  webpack: (config, { dev, isServer }) => {
    // Применяем обфускацию только в production-сборке и только для клиентской части
    if (!dev && !isServer) {
      config.plugins.push(
        new WebpackObfuscator(
          {
            compact: true,                     // Сжимает код
            controlFlowFlattening: true,        // Усложняет структуру кода
            controlFlowFlatteningThreshold: 0.75,
            deadCodeInjection: true,            // Внедряет «мертвый» код
            deadCodeInjectionThreshold: 0.4,
            debugProtection: true,               // Защита от отладки
            debugProtectionInterval: 2000,        // Интервал защиты
            disableConsoleOutput: true,           // Отключает console.log
            identifierNamesGenerator: 'hexadecimal', // Переименовывает переменные в hex
            numbersToExpressions: true,            // Преобразует числа в выражения
          },
          [] // Список исключений (оставляем пустым)
        )
      );
    }
    return config;
  },
};

module.exports = nextConfig;