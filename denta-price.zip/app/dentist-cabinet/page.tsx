﻿"use client";

import React, { useState, useEffect, useRef, useCallback } from 'react';

import { services as servicesCatalog } from '@/app/data/services';
import { loadAlmatyPrices, loadPromotionPrices } from '../../pricing/loaders';
import { SEGMENTS_CONFIG } from '../../pricing/fallback';
import type { AlmatyServicePrice, SegmentConfig, PromotionPriceMap } from '../../pricing/types';

interface ServiceRow {
  id: string;
  serviceId: string;
  price: number | null;
  radiusKm: 1 | 3 | 6 | 'city';
  isPaid: boolean;
  paidAt: string | null;
  activeFrom: string | null;
  segment?: string;
  whatsappClicks?: number;
  views1km?: number;
  views3km?: number;
  views6km?: number;
  viewsCity?: number;
}

interface NicheStatusResponse {
  status: 'green' | 'yellow' | 'red';
  price: number;
  message?: string;
}

const getDentistId = () => {
  if (typeof window === 'undefined') return 'doctor-1';
  try {
    const v = new URLSearchParams(window.location.search).get('dentistId');
    return (v && v.trim()) ? v.trim() : 'doctor-1';
  } catch {
    return 'doctor-1';
  }
};

const nsKey = (baseKey: string) => {
  const dentistId = getDentistId();
  return `${baseKey}:${dentistId}`;
};

const STORAGE_KEY_BASE = 'dentist-cabinet-service-rows';

const loadServiceRowsFromStorage = (): ServiceRow[] => {
  if (typeof window === 'undefined') return [];

  try {
    const stored = localStorage.getItem(nsKey(STORAGE_KEY_BASE));
    if (stored) {
      const parsed = JSON.parse(stored);
      return parsed.map((row: any) => {
        const priceNum = Number(row.price);
        return {
          ...row,
          price: row.price === null ? null : (isNaN(priceNum) ? null : priceNum),
          radiusKm: row.radiusKm as 1 | 3 | 6 | 'city',
          isPaid: Boolean(row.isPaid),
          segment: row.segment || '',
          whatsappClicks: row.whatsappClicks || 0,
          views1km: row.views1km || 0,
          views3km: row.views3km || 0,
          views6km: row.views6km || 0,
          viewsCity: row.viewsCity || 0,
        };
      });
    }
  } catch (error) {
    console.error('Failed to load service rows from storage:', error);
  }

  return [];
};

const saveServiceRowsToStorage = (rows: ServiceRow[]) => {
  if (typeof window === 'undefined') return;

  try {
    localStorage.setItem(nsKey(STORAGE_KEY_BASE), JSON.stringify(rows));
  } catch (error) {
    console.error('Failed to save service rows to storage:', error);
  }
};

const PROFILE_KEYS = {
  fullName: 'dentist-profile-full-name',
  photoUrl: 'dentist-profile-photo-url',
  whatsapp: 'dentist-profile-whatsapp',
  address: 'dentist-profile-address',
} as const;

type DentistProfileSnapshot = {
  fullName: string;
  photoUrl: string;
  whatsapp: string;
  address: string;
};

const loadProfileSnapshotFromStorage = (): DentistProfileSnapshot | null => {
  if (typeof window === 'undefined') return null;

  try {
    const fullName = localStorage.getItem(nsKey(PROFILE_KEYS.fullName)) ?? '';
    const photoUrl = localStorage.getItem(nsKey(PROFILE_KEYS.photoUrl)) ?? '';
    const whatsapp = localStorage.getItem(nsKey(PROFILE_KEYS.whatsapp)) ?? '';
    const address = localStorage.getItem(nsKey(PROFILE_KEYS.address)) ?? '';

    return {
      fullName,
      photoUrl,
      whatsapp,
      address,
    };
  } catch {
    return null;
  }
};

const saveProfileSnapshotToStorage = (snap: DentistProfileSnapshot) => {
  if (typeof window === 'undefined') return;

  try {
    if (snap.fullName) localStorage.setItem(nsKey(PROFILE_KEYS.fullName), String(snap.fullName));
    if (snap.photoUrl) localStorage.setItem(nsKey(PROFILE_KEYS.photoUrl), String(snap.photoUrl));
    if (snap.whatsapp) localStorage.setItem(nsKey(PROFILE_KEYS.whatsapp), String(snap.whatsapp));
    if (snap.address) localStorage.setItem(nsKey(PROFILE_KEYS.address), String(snap.address));
  } catch (error) {
    console.error('Failed to save profile snapshot to storage:', error);
  }
};

const PUBLIC_ADS_SNAPSHOT_KEY_BASE = 'dentaprice-public-ads-snapshot';

type PublicAdsServiceRow = {
  serviceId: string;
  price: number;
  radiusKm: 1 | 3 | 6 | 'city';
  segment: string;
  activeFrom: string;
};

type PublicAdsSnapshot = {
  updatedAt: string;
  profile: DentistProfileSnapshot;
  services: PublicAdsServiceRow[];
};

const savePublicAdsSnapshotToStorage = (snap: PublicAdsSnapshot) => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(nsKey(PUBLIC_ADS_SNAPSHOT_KEY_BASE), JSON.stringify(snap));
  } catch (error) {
    console.error('Failed to save public ads snapshot:', error);
  }
};

interface DocumentData {
  name: string;
  type: string;
  dataUrl: string;
}

const DOCUMENT_KEYS = {
  diploma: 'dentist-profile-diploma',
  certificate: 'dentist-profile-certificate',
  category: 'dentist-profile-category',
} as const;

const loadDocumentFromStorage = (key: string): DocumentData | null => {
  if (typeof window === 'undefined') return null;

  try {
    const stored = localStorage.getItem(key);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error(`Failed to load document ${key} from storage:`, error);
  }

  return null;
};

const saveDocumentToStorage = (key: string, data: DocumentData | null) => {
  if (typeof window === 'undefined') return;

  try {
    if (data) {
      localStorage.setItem(key, JSON.stringify(data));
    } else {
      localStorage.removeItem(key);
    }
  } catch (error) {
    console.error(`Failed to save document ${key} to storage:`, error);
  }
};

const getAlmatyPriceByServiceId = (serviceId: string, almatyPrices: AlmatyServicePrice[]): AlmatyServicePrice | undefined => {
  const sid = String(serviceId || '').trim().toLowerCase();
  if (!sid) return undefined;

  const service = servicesCatalog.find(s => String(s.id || '').trim().toLowerCase() === sid);
  const ruName = String((service as any)?.nameRU ?? '').trim().toLowerCase();
  const kzName = String((service as any)?.nameKZ ?? '').trim().toLowerCase();

  console.log('[getAlmatyPriceByServiceId] Looking for:', { serviceId, sid, ruName, kzName });
  console.log('[getAlmatyPriceByServiceId] Available prices count:', almatyPrices.length);
  if (almatyPrices.length > 0) {
    console.log('[getAlmatyPriceByServiceId] Sample price:', almatyPrices[0]);
  }

  const anyPrices: any = almatyPrices as any;

  const matchByAnyKey = (p: any): boolean => {
    const pid = String(p?.serviceId ?? p?.id ?? '').trim().toLowerCase();
    if (pid && pid === sid) return true;

    const pRu = String(p?.serviceNameRU ?? p?.nameRU ?? p?.serviceName ?? p?.name ?? '').trim().toLowerCase();
    if (ruName && pRu && pRu === ruName) return true;

    const pKz = String(p?.serviceNameKZ ?? p?.nameKZ ?? '').trim().toLowerCase();
    if (kzName && pKz && pKz === kzName) return true;

    return false;
  };

  if (Array.isArray(anyPrices)) {
    return anyPrices.find((p: any) => matchByAnyKey(p));
  }

  if (anyPrices && typeof anyPrices === 'object') {
    const directKey = String(serviceId).trim();
    if (anyPrices[directKey]) return anyPrices[directKey] as AlmatyServicePrice;
    if (anyPrices[sid]) return anyPrices[sid] as AlmatyServicePrice;

    const values = Object.values(anyPrices);
    return values.find((p: any) => matchByAnyKey(p)) as AlmatyServicePrice | undefined;
  }

  return undefined;
};

const getSegmentConfigWithRealRanges = (almatyPrice?: AlmatyServicePrice): SegmentConfig[] => {
  const entries = Object.entries(SEGMENTS_CONFIG as any);

  if (!almatyPrice) {
    return entries.map(([key, cfg]: any) => ({
      key,
      ...cfg,
      min: Number.NaN,
      max: Number.NaN,
    })) as SegmentConfig[];
  }

  const economMax = Number((almatyPrice as any).econom);
  const comfortMax = Number((almatyPrice as any).comfort);
  const optimumMax = Number((almatyPrice as any).optimum);
  const premiumMax = Number((almatyPrice as any).premium);
  const luxuryMax = Number((almatyPrice as any).luxury);

  return entries.map(([key, cfg]: any) => {
    let min = Number.NaN;
    let max = Number.NaN;

    if (!Number.isFinite(economMax) || !Number.isFinite(comfortMax) || !Number.isFinite(optimumMax) || !Number.isFinite(premiumMax) || !Number.isFinite(luxuryMax)) {
      return { key, ...cfg, min, max };
    }

    if (key === 'econom') { min = 0; max = economMax; }
    if (key === 'comfort') { min = economMax + 1; max = comfortMax; }
    if (key === 'optimum') { min = comfortMax + 1; max = optimumMax; }
    if (key === 'premium') { min = optimumMax + 1; max = premiumMax; }
    if (key === 'luxury') { min = premiumMax + 1; max = luxuryMax; }

    return { key, ...cfg, min, max };
  }) as SegmentConfig[];
};

const parsePriceNums = (v: unknown): number[] => {
  if (typeof v === 'number' && Number.isFinite(v)) return [v];
  if (typeof v !== 'string') return [];
  const matches = v.match(/\d[\d\s]*/g) || [];
  return matches
    .map(s => Number(String(s).replace(/\s+/g, '')))
    .filter(n => Number.isFinite(n));
};

const getCeilingFromRange = (segment: 'econom' | 'comfort' | 'optimum' | 'premium' | 'luxury', raw: unknown): number | null => {
  const nums = parsePriceNums(raw);
  if (nums.length === 0) return null;

  if (segment === 'luxury') return nums[0];
  if (segment === 'econom') return nums[nums.length - 1];
  return nums.length >= 2 ? nums[1] : nums[0];
};

const normalizeAlmatyPrices = (prices: AlmatyServicePrice[]): AlmatyServicePrice[] => {
  if (!prices || !Array.isArray(prices)) return [];

  return prices.map((p: any) => ({
    serviceId: p.serviceId,
    econom: typeof p.econom === 'number' ? p.econom : null,
    comfort: typeof p.comfort === 'number' ? p.comfort : null,
    optimum: typeof p.optimum === 'number' ? p.optimum : null,
    premium: typeof p.premium === 'number' ? p.premium : null,
    luxury: typeof p.luxury === 'number' ? p.luxury : null,
  }));
};

export default function DentistCabinetDesktopCompositionPage() {
  const doctorPhotoUrl = "/images/doctors/doctor1.png";

  const buttonBase = "inline-flex items-center justify-center h-8 rounded-md border px-3 text-sm leading-5 whitespace-nowrap";
  const inputBase = "w-full h-8 rounded-md border px-3 text-sm leading-5";

  const unifiedButtonStyle = {
    height: '24px',
    padding: '0 8px',
    fontSize: '11px',
    lineHeight: '22px',
    border: '1px solid #9ca3af',
    borderRadius: '6px',
    background: '#e5e7eb',
    color: '#000000',
    cursor: 'pointer',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '4px',
    whiteSpace: 'nowrap' as const
  };

  const [servicesHeight, setServicesHeight] = useState(250);
  const isDraggingRef = useRef(false);
  const startYRef = useRef(0);
  const startHeightRef = useRef(0);

  const [almatyPrices, setAlmatyPrices] = useState<AlmatyServicePrice[]>([]);
  const [promotionPrices, setPromotionPrices] = useState<PromotionPriceMap>({});

  const [nicheStatuses, setNicheStatuses] = useState<Record<string, { status: 'green' | 'yellow' | 'red'; price: number }>>({});

  const createEmptyServiceRow = (id?: string): ServiceRow => ({
    id: id ?? `${Date.now()}_${Math.random().toString(16).slice(2)}`,
    serviceId: '',
    price: null,
    radiusKm: 'city',
    isPaid: false,
    paidAt: null,
    activeFrom: null,
    segment: '',
    whatsappClicks: 0,
    views1km: 0,
    views3km: 0,
    views6km: 0,
    viewsCity: 0,
  });

  const [serviceRows, setServiceRows] = useState<ServiceRow[]>([
    createEmptyServiceRow(),
    createEmptyServiceRow(),
    createEmptyServiceRow(),
  ]);

  const [activeService, setActiveService] = useState<string | null>(null);
  const [analyticsRowId, setAnalyticsRowId] = useState<string | null>(null);

  const [isMounted, setIsMounted] = useState(false);

  const [profileFullName, setProfileFullName] = useState('');
  const [profilePhotoUrl, setProfilePhotoUrl] = useState(doctorPhotoUrl);
  const [profileWhatsapp, setProfileWhatsapp] = useState('');
  const [profileAddress, setProfileAddress] = useState('');

  const [diploma, setDiploma] = useState<DocumentData | null>(null);
  const [certificate, setCertificate] = useState<DocumentData | null>(null);
  const [category, setCategory] = useState<DocumentData | null>(null);

  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const profileInitRef = useRef(false);

  const [activeTab, setActiveTab] = useState<'services' | 'profile' | 'reports'>('services');

  const [windowWidth, setWindowWidth] = useState(1200);

  const [tempServiceId, setTempServiceId] = useState<string>('');
  const [tempPrice, setTempPrice] = useState<number | null>(null);
  const [tempRadius, setTempRadius] = useState<1 | 3 | 6 | 'city'>('city');

  const updatePriceAbortControllerRef = useRef<AbortController | null>(null);
  const updateRadiusAbortControllerRef = useRef<AbortController | null>(null);
  const priceTimeoutRef = useRef<Map<string, NodeJS.Timeout>>(new Map());

  const isInitialLoad = useRef(true);
  const isMountedRef = useRef(true);
  const hasInitializedServiceRowsRef = useRef(false);
  
  const [localPrices, setLocalPrices] = useState<Map<string, string>>(new Map());

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (!analyticsRowId) return;
    const row = serviceRows.find(r => r.id === analyticsRowId);
    if (!row) return;
    if (!row.serviceId) return;

    const segment = row.segment || getSegment(row.price, row.serviceId);
    if (!segment) return;

    const { serviceId, radiusKm, price } = row;

    const abortController = new AbortController();

    fetch(`/api/niche-status?serviceId=${serviceId}&segment=${segment}&radius=${radiusKm}&price=${price}`, {
      signal: abortController.signal
    })
      .then(async res => {
        if (!res.ok) {
          if (res.status === 404) {
            console.warn('Niche status not found for:', serviceId);
            return null;
          }
          throw new Error(`HTTP ${res.status}`);
        }
        return res.json();
      })
      .then((data: NicheStatusResponse | null) => {
        if (data && data.status && data.price) {
          setNicheStatuses(prev => ({
            ...prev,
            [analyticsRowId]: { status: data.status, price: data.price }
          }));
        }
      })
      .catch(err => {
        if (err.name !== 'AbortError') console.error('Failed to fetch niche status:', err);
      });

    return () => abortController.abort();
  }, [analyticsRowId, serviceRows]);

  useEffect(() => {
    if (isInitialLoad.current || serviceRows.length === 0) return;

    const abortController = new AbortController();

    const fetchNicheStatuses = async () => {
      for (const row of serviceRows) {
        if (abortController.signal.aborted) break;
        
        if (!row.serviceId || row.price === null || !row.segment || !row.radiusKm) continue;
        
        // Вычисляем локальную цену
        const multiplier = promotionPrices[row.segment]?.[String(row.radiusKm)];
        const localPrice = multiplier && row.price ? Math.round(row.price * multiplier) : null;
        const existing = nicheStatuses[row.id];
        
        // Если уже есть правильная цена — пропускаем
        if (existing && localPrice && existing.price === localPrice) continue;
        
        try {
          const res = await fetch(`/api/niche-status?serviceId=${row.serviceId}&segment=${row.segment}&radius=${row.radiusKm}&price=${row.price}`, {
            signal: abortController.signal
          });
          if (res.ok) {
            const data = await res.json();
            setNicheStatuses(prev => ({ ...prev, [row.id]: data }));
          }
        } catch (e) {
          if (e.name !== 'AbortError') console.error("Niche Fetch Error", e);
        }
      }
    };
    fetchNicheStatuses();

    return () => abortController.abort();
  }, [serviceRows, promotionPrices, nicheStatuses]);

  useEffect(() => {
    if (!profileFullName && !profileWhatsapp && !profileAddress) {
      setActiveTab('profile');
    }
  }, [profileFullName, profileWhatsapp, profileAddress]);

  useEffect(() => {
    if (!isMounted) return;
    if (analyticsRowId) return;

    const firstWithService = serviceRows.find(r => String(r.serviceId || '').trim() !== '');
    const pick = firstWithService?.id ?? (serviceRows.length > 0 ? serviceRows[0].id : null);
    if (!pick) return;

    setAnalyticsRowId(pick);
    setActiveService(pick);
  }, [isMounted, analyticsRowId, serviceRows]);

  const columnWidths = {
    service: '35%',
    price: '15%',
    segment: '10%',
    promotion: '10%',
    visibility: '5%',
    payment: '5%',
    delete: '40px'
  };

  const headerContainerRef = useRef<HTMLDivElement>(null);
  const bodyContainerRef = useRef<HTMLDivElement>(null);
  const [scrollbarWidth, setScrollbarWidth] = useState(0);

  const updateScrollbarWidth = useCallback(() => {
    if (bodyContainerRef.current) {
      const width = bodyContainerRef.current.offsetWidth - bodyContainerRef.current.clientWidth;
      setScrollbarWidth(width);
    }
  }, []);

  useEffect(() => {
    setIsMounted(true);
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      console.log('[fetchData] Starting...');
      const ap = await loadAlmatyPrices();
      console.log('[fetchData] almatyPrices loaded, count:', ap.length);
      console.log('[fetchData] almatyPrices sample (first 3):', ap.slice(0, 3));
      console.log('[fetchData] almatyPrices keys in first item:', Object.keys(ap[0] || {}));
      
      const pp = await loadPromotionPrices();
      console.log('[fetchData] promotionPrices loaded, keys:', Object.keys(pp || {}));
      
      setAlmatyPrices(normalizeAlmatyPrices(ap));
      
      const transformedPrices: PromotionPriceMap = {};
      if (pp && pp.multipliers) {
        Object.entries(pp.multipliers).forEach(([segment, radiiData]) => {
          transformedPrices[segment] = radiiData as Record<string, number>;
        });
      }
      setPromotionPrices(transformedPrices);

      const dentistId = getDentistId();
      try {
        const res = await fetch(`/api/dentists/${dentistId}`);
        if (res.ok) {
          const data = await res.json();
          if (data && typeof data === 'object') {
            if (data.fullName) setProfileFullName(data.fullName);
            if (data.photoUrl) setProfilePhotoUrl(data.photoUrl);
            if (data.whatsapp) setProfileWhatsapp(data.whatsapp);
            if (data.address) setProfileAddress(data.address);
            
            if (Array.isArray(data.services)) {
              const servicesWithId = data.services.map((service: any) => ({
                ...service,
                id: service.id || createEmptyServiceRow().id,
                whatsappClicks: service.whatsappClicks || 0,
                views1km: service.views1km || 0,
                views3km: service.views3km || 0,
                views6km: service.views6km || 0,
                viewsCity: service.viewsCity || 0,
              }));
              setServiceRows(servicesWithId);
              hasInitializedServiceRowsRef.current = true;
              isInitialLoad.current = false;
              return;
            }
          }
        }
      } catch (e) {
        console.error("Fetch error", e);
      }

      const saved = localStorage.getItem(nsKey(STORAGE_KEY_BASE));
      if (saved) {
        try {
          setServiceRows(JSON.parse(saved));
        } catch {
          // ignore
        }
      }
      isInitialLoad.current = false;
    };

    fetchData();
  }, []);

  useEffect(() => {
    const dentistId = getDentistId();
    if (!dentistId || dentistId === 'doctor-1') return;

    if (isInitialLoad.current) {
      return;
    }

    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }

    saveTimeoutRef.current = setTimeout(() => {
      fetch(`/api/dentists/${dentistId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: profileFullName || '',
          photoUrl: profilePhotoUrl || '',
          whatsapp: profileWhatsapp || '',
          address: profileAddress || '',
          services: serviceRows || [],
        }),
      })
        .then(res => {
          if (!res.ok) {
            console.error('Failed to save dentist data on server');
          }
        })
        .catch(err => console.error('Failed to save dentist data:', err));
    }, 500);

    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
    };
  }, [profileFullName, profilePhotoUrl, profileWhatsapp, profileAddress, serviceRows]);

  useEffect(() => {
    if (!isMounted) return;
    if (!hasInitializedServiceRowsRef.current) return;
    saveServiceRowsToStorage(serviceRows);
  }, [isMounted, serviceRows]);

  useEffect(() => {
    const observer = new ResizeObserver(updateScrollbarWidth);
    if (bodyContainerRef.current) {
      observer.observe(bodyContainerRef.current);
    }
    return () => observer.disconnect();
  }, [updateScrollbarWidth]);

  useEffect(() => {
    updateScrollbarWidth();
  }, [servicesHeight, serviceRows, updateScrollbarWidth]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    isDraggingRef.current = true;
    startYRef.current = e.clientY;
    startHeightRef.current = servicesHeight;
    e.preventDefault();
  }, [servicesHeight]);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDraggingRef.current) return;
    const deltaY = e.clientY - startYRef.current;
    const newHeight = Math.max(200, Math.min(700, startHeightRef.current + deltaY));
    setServicesHeight(newHeight);
  }, []);

  const handleMouseUp = useCallback(() => {
    isDraggingRef.current = false;
  }, []);

  useEffect(() => {
    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (isDraggingRef.current) {
        handleMouseMove(e);
      }
    };

    const handleGlobalMouseUp = () => {
      if (isDraggingRef.current) {
        handleMouseUp();
      }
    };

    window.addEventListener('mousemove', handleGlobalMouseMove);
    window.addEventListener('mouseup', handleGlobalMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  const getSegment = (price: number | null, serviceId?: string): string => {
    if (price === null || !serviceId) return '';

    const normalizedPrice = Number(String(price).replace(/\s/g, '').replace(',', '.'));
    if (isNaN(normalizedPrice) || normalizedPrice < 0) return '';

    const almatyPrice = getAlmatyPriceByServiceId(serviceId, almatyPrices);
    
    if (!almatyPrice) return '';

    const economMax = (almatyPrice as any).econom;
    const comfortMax = (almatyPrice as any).comfort;
    const optimumMax = (almatyPrice as any).optimum;
    const premiumMax = (almatyPrice as any).premium;
    const luxuryMax = (almatyPrice as any).luxury;

    if (economMax === null || comfortMax === null || optimumMax === null || premiumMax === null || luxuryMax === null) return '';

    if (normalizedPrice <= economMax) return 'econom';
    if (normalizedPrice <= comfortMax) return 'comfort';
    if (normalizedPrice <= optimumMax) return 'optimum';
    if (normalizedPrice <= premiumMax) return 'premium';
    if (normalizedPrice <= luxuryMax) return 'luxury';

    return 'luxury';
  };

  const getServiceNameKZ = (serviceId: string): string => {
    const service = servicesCatalog.find(s => s.id === serviceId);
    if (!service) return '';
    const kz = String((service as any).nameKZ || '').trim();
    const ru = String((service as any).nameRU || '').trim();
    if (!kz) return '';
    if (ru && kz.toLowerCase() === ru.toLowerCase()) return '';
    return kz;
  };

  const getServiceNameRU = (serviceId: string): string => {
    const service = servicesCatalog.find(s => s.id === serviceId);
    return service?.nameRU || '';
  };

  const getServiceDisplayName = (rowId: string): string => {
    const row = serviceRows.find(r => r.id === rowId);
    if (!row) return '';
    return getServiceNameRU(row.serviceId);
  };

  const handleServiceSelect = (rowId: string) => {
    setActiveService(activeService === rowId ? null : rowId);
    setAnalyticsRowId(rowId);
  };

  const handleAddServiceRow = () => {
    setServiceRows(prev => [...prev, createEmptyServiceRow()]);
  };

  const handleAddTempRow = () => {
    if (!tempServiceId) {
      alert('Выберите услугу');
      return;
    }
    const newRow = createEmptyServiceRow();
    newRow.serviceId = tempServiceId;
    newRow.price = tempPrice;
    newRow.radiusKm = tempRadius;
    if (tempPrice !== null) {
      newRow.segment = getSegment(tempPrice, tempServiceId);
    }
    
    setServiceRows(prev => {
      const updated = [...prev, newRow];
      setTimeout(() => {
        if (newRow.serviceId && newRow.price !== null && newRow.segment && newRow.radiusKm) {
          fetch(`/api/niche-status?serviceId=${newRow.serviceId}&segment=${newRow.segment}&radius=${newRow.radiusKm}&price=${newRow.price}`)
            .then(async res => {
              if (res.ok) {
                const data = await res.json();
                setNicheStatuses(prevStatuses => ({ ...prevStatuses, [newRow.id]: data }));
              }
            })
            .catch(console.error);
        }
      }, 0);
      return updated;
    });
    
    setTempPrice(null);
    setTempRadius('city');
  };

  const updateServiceRow = (rowId: string, newServiceId: string) => {
    setServiceRows(prevRows =>
      prevRows.map(row => {
        if (row.id === rowId) {
          const nextSegment =
            isMounted && almatyPrices.length > 0 && row.price !== null && newServiceId
              ? getSegment(row.price, newServiceId)
              : '';
          return {
            ...row,
            serviceId: newServiceId,
            price: row.price,
            segment: nextSegment,
          };
        }
        return row;
      })
    );

    setTimeout(() => {
      const updatedRow = serviceRows.find(r => r.id === rowId);
      if (updatedRow && updatedRow.serviceId && updatedRow.price !== null && updatedRow.segment && updatedRow.radiusKm) {
        fetch(`/api/niche-status?serviceId=${updatedRow.serviceId}&segment=${updatedRow.segment}&radius=${updatedRow.radiusKm}&price=${updatedRow.price}`)
          .then(async res => {
            if (res.ok) {
              const data = await res.json();
              setNicheStatuses(prev => ({ ...prev, [rowId]: data }));
            }
          })
          .catch(console.error);
      }
    }, 0);
  };

  const updateServicePrice = (rowId: string, val: string) => {
    const cleanVal = val.replace(/\D/g, '');
    const numericPrice = cleanVal === '' ? null : Number(cleanVal);

    console.log('[updateServicePrice] rowId:', rowId, 'val:', val, 'cleanVal:', cleanVal, 'numericPrice:', numericPrice);

    const currentRow = serviceRows.find(r => r.id === rowId);
    
    if (currentRow?.price === numericPrice) return;

    setServiceRows(prevRows =>
      prevRows.map(row => {
        if (row.id === rowId) {
          return { ...row, price: numericPrice };
        }
        return row;
      })
    );

    if (updatePriceAbortControllerRef.current) {
      updatePriceAbortControllerRef.current.abort();
    }
    updatePriceAbortControllerRef.current = new AbortController();

    const timeout = setTimeout(() => {
      const updatedRow = serviceRows.find(r => r.id === rowId);
      if (!updatedRow || updatedRow.price === null || !updatedRow.serviceId) return;

      const nextSegment = getSegment(updatedRow.price, updatedRow.serviceId);
      
      setServiceRows(prevRows =>
        prevRows.map(row => {
          if (row.id === rowId) {
            return { ...row, segment: nextSegment };
          }
          return row;
        })
      );

      setNicheStatuses(prev => {
        const { [rowId]: _, ...rest } = prev;
        return rest;
      });

      fetch(`/api/niche-status?serviceId=${updatedRow.serviceId}&segment=${nextSegment}&radius=${updatedRow.radiusKm}&price=${updatedRow.price}`, {
        signal: updatePriceAbortControllerRef.current?.signal
      })
        .then(async res => {
          if (res.ok) {
            const data = await res.json();
            setNicheStatuses(prev => ({ ...prev, [rowId]: data }));
          }
        })
        .catch(err => {
          if (err.name !== 'AbortError') console.error(err);
        });
      
      priceTimeoutRef.current.delete(rowId);
    }, 1000);
    
    priceTimeoutRef.current.set(rowId, timeout);
  };

  const updateServiceRadius = (rowId: string, newRadiusKm: 1 | 3 | 6 | 'city') => {
    setServiceRows(prevRows =>
      prevRows.map(row => {
        if (row.id === rowId) {
          return {
            ...row,
            radiusKm: newRadiusKm,
          };
        }
        return row;
      })
    );

    setNicheStatuses(prev => {
      const { [rowId]: _, ...rest } = prev;
      return rest;
    });

    if (updateRadiusAbortControllerRef.current) {
      updateRadiusAbortControllerRef.current.abort();
    }
    updateRadiusAbortControllerRef.current = new AbortController();

    setTimeout(() => {
      const updatedRow = serviceRows.find(r => r.id === rowId);
      if (updatedRow && updatedRow.serviceId && updatedRow.price !== null && updatedRow.segment && updatedRow.radiusKm) {
        fetch(`/api/niche-status?serviceId=${updatedRow.serviceId}&segment=${updatedRow.segment}&radius=${updatedRow.radiusKm}&price=${updatedRow.price}`, {
          signal: updateRadiusAbortControllerRef.current?.signal
        })
          .then(async res => {
            if (res.ok) {
              const data = await res.json();
              setNicheStatuses(prev => ({ ...prev, [rowId]: data }));
            }
          })
          .catch(err => {
            if (err.name !== 'AbortError') console.error(err);
          });
      }
    }, 0);
  };

  const handlePayService = (rowId: string) => {
    const row = serviceRows.find(r => r.id === rowId);
    console.log('[handlePayService] rowId:', rowId, 'row:', row);
    if (!row) return;
    if (row.price === null) return;
    if (!row.serviceId || String(row.serviceId).trim() === '') return;
    if (!row.segment || String(row.segment).trim() === '') return;

    const dynamicData = nicheStatuses[rowId];
    let fee;
    if (dynamicData) {
      fee = dynamicData.price;
    } else {
      const multiplier = promotionPrices[row.segment]?.[String(row.radiusKm)];
      if (multiplier && row.price) {
        fee = Math.round(row.price * multiplier);
      }
    }
    console.log('[handlePayService] dynamicData:', dynamicData, 'fee:', fee);
    if (fee === undefined || fee === null) return;

    const dentistId = getDentistId();
    if (!dentistId) return;

    fetch('/api/promo-payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        dentistId,
        serviceId: row.serviceId,
        segment: row.segment,
        radius: row.radiusKm,
        amount: fee,
      }),
    })
      .then(async (response) => {
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          alert(errorData.error || 'Payment error');
          return;
        }

        const data = await response.json();
        if (data.success) {
          localStorage.setItem(`promo_payment_record_id_${rowId}`, data.paymentRecordId);

          const now = new Date().toISOString();
          let nextRows: ServiceRow[] = [];

          setServiceRows(prevRows => {
            nextRows = prevRows.map(r => {
              if (r.id !== rowId) return r;
              return {
                ...r,
                isPaid: true,
                paidAt: now,
                activeFrom: now,
              };
            });
            return nextRows;
          });

          setTimeout(() => {
            const now2 = new Date().toISOString();

            const services = nextRows
              .filter(r => r.isPaid && r.activeFrom && r.price !== null && String(r.serviceId || '').trim() !== '' && String(r.segment || '').trim() !== '')
              .map(r => ({
                serviceId: String(r.serviceId),
                price: Number(r.price),
                radiusKm: r.radiusKm,
                segment: String(r.segment || ''),
                activeFrom: String(r.activeFrom),
              }));

            const snap = {
              updatedAt: now2,
              profile: {
                fullName: profileFullName || '',
                photoUrl: profilePhotoUrl || '',
                whatsapp: profileWhatsapp || '',
                address: profileAddress || '',
              },
              services,
            };

            savePublicAdsSnapshotToStorage(snap);

            fetch(`/api/dentists/${dentistId}/public-ads`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(snap),
            })
              .then(res => {
                if (!res.ok) {
                  console.error('Failed to update public ads on server');
                }
              })
              .catch(err => console.error('Failed to update public ads:', err));
          }, 0);
        }
      })
      .catch((error) => {
        console.error('Payment request failed:', error);
        alert('Payment error');
      });
  };

  const handleEvictService = (rowId: string, views: number, whatsapp: number) => {
    const row = serviceRows.find(r => r.id === rowId);
    if (!row || !row.isPaid || !row.activeFrom) return;

    setServiceRows(prevRows =>
      prevRows.map(r => {
        if (r.id !== rowId) return r;
        return {
          ...r,
          views1km: (r.views1km || 0) + views,
          views3km: (r.views3km || 0) + views,
          views6km: (r.views6km || 0) + views,
          viewsCity: (r.viewsCity || 0) + views,
          whatsappClicks: (r.whatsappClicks || 0) + whatsapp,
        };
      })
    );

    const now = new Date().toISOString();
    let nextRows: ServiceRow[] = [];

    setServiceRows(prevRows => {
      nextRows = prevRows.map(r => {
        if (r.id !== rowId) return r;
        return {
          ...r,
          isPaid: false,
          paidAt: null,
          activeFrom: null,
        };
      });
      return nextRows;
    });

    setTimeout(() => {
      const now2 = new Date().toISOString();

      const services = nextRows
        .filter(r => r.isPaid && r.activeFrom && r.price !== null && String(r.serviceId || '').trim() !== '' && String(r.segment || '').trim() !== '')
        .map(r => ({
          serviceId: String(r.serviceId),
          price: Number(r.price),
          radiusKm: r.radiusKm,
          segment: String(r.segment || ''),
          activeFrom: String(r.activeFrom),
        }));

      const snap = {
        updatedAt: now2,
        profile: {
          fullName: profileFullName || '',
          photoUrl: profilePhotoUrl || '',
          whatsapp: profileWhatsapp || '',
          address: profileAddress || '',
        },
        services,
      };

      savePublicAdsSnapshotToStorage(snap);

      const dentistId = getDentistId();
      if (dentistId) {
        fetch(`/api/dentists/${dentistId}/public-ads`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(snap),
        })
          .then(res => {
            if (!res.ok) {
              console.error('Failed to update public ads on server');
            }
          })
          .catch(err => console.error('Failed to update public ads:', err));
      }
    }, 0);
  };

  const handleSaveProfile = async () => {
    const dentistId = getDentistId();
    if (!dentistId || dentistId === 'doctor-1') return;

    try {
      const response = await fetch(`/api/dentists/${dentistId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: profileFullName || '',
          photoUrl: profilePhotoUrl || '',
          whatsapp: profileWhatsapp || '',
          address: profileAddress || '',
          services: serviceRows || [],
        }),
      });

      if (!response.ok) {
        console.error('Failed to save profile');
        alert('Не удалось сохранить профиль');
      } else {
        alert('Профиль сохранен');
      }
    } catch (error) {
      console.error('Save profile error:', error);
      alert('Ошибка сохранения');
    }
  };

  const handleLogout = () => {
    const dentistId = getDentistId();
    if (dentistId) {
      const keysToRemove = [
        nsKey(STORAGE_KEY_BASE),
        nsKey(PROFILE_KEYS.fullName),
        nsKey(PROFILE_KEYS.photoUrl),
        nsKey(PROFILE_KEYS.whatsapp),
        nsKey(PROFILE_KEYS.address),
        nsKey(PUBLIC_ADS_SNAPSHOT_KEY_BASE),
        DOCUMENT_KEYS.diploma,
        DOCUMENT_KEYS.certificate,
        DOCUMENT_KEYS.category,
      ];
      keysToRemove.forEach(key => localStorage.removeItem(key));
    }
    window.location.href = '/';
  };

  const groupedServices = servicesCatalog.reduce((acc, service) => {
    if (!acc[service.category]) {
      acc[service.category] = [];
    }
    acc[service.category].push(service);
    return acc;
  }, {} as Record<string, typeof servicesCatalog>);

  const analyticsRow = analyticsRowId ? serviceRows.find(row => row.id === analyticsRowId) : null;

  const getActivePaidServices = () => {
    return serviceRows.filter(row => row.isPaid && row.activeFrom !== null);
  };

  useEffect(() => {
    const loadedDiploma = loadDocumentFromStorage(DOCUMENT_KEYS.diploma);
    const loadedCertificate = loadDocumentFromStorage(DOCUMENT_KEYS.certificate);
    const loadedCategory = loadDocumentFromStorage(DOCUMENT_KEYS.category);

    if (loadedDiploma) setDiploma(loadedDiploma);
    if (loadedCertificate) setCertificate(loadedCertificate);
    if (loadedCategory) setCategory(loadedCategory);
  }, []);

  useEffect(() => {
    if (profileInitRef.current) return;
    profileInitRef.current = true;

    const snap = loadProfileSnapshotFromStorage();
    if (!snap) return;

    setProfileFullName(snap.fullName || '');
    setProfileWhatsapp(snap.whatsapp || '');
    setProfileAddress(snap.address || '');
    if (snap.photoUrl) setProfilePhotoUrl(snap.photoUrl);
  }, []);

  useEffect(() => {
    saveProfileSnapshotToStorage({
      fullName: profileFullName,
      photoUrl: profilePhotoUrl,
      whatsapp: profileWhatsapp,
      address: profileAddress,
    });
  }, [profileFullName, profilePhotoUrl, profileWhatsapp, profileAddress]);

  // Добавленный эффект для обновления сегментов при загрузке цен
  useEffect(() => {
    // Не пересчитываем, если цены ещё не загружены или компонент не смонтирован
    if (almatyPrices.length === 0 || !isMounted) return;

    let updated = false;
    const newRows = serviceRows.map((row) => {
      // Если у строки нет услуги или цены – пропускаем
      if (!row.serviceId || row.price === null) return row;

      // Вычисляем актуальный сегмент
      const newSegment = getSegment(row.price, row.serviceId);
      // Если сегмент изменился (или был пуст) – обновляем
      if (newSegment !== row.segment) {
        updated = true;
        return { ...row, segment: newSegment };
      }
      return row;
    });

    if (updated) {
      setServiceRows(newRows);
    }
  }, [almatyPrices, serviceRows, isMounted]);

  const handleDocumentUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
    documentType: 'profile' | 'certificate' | 'category',
    onSuccess?: (url: string) => void
  ) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      alert('Файл слишком большой. Максимальный размер 10MB.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', documentType);
    formData.append('dentistId', getDentistId());

    try {
      const response = await fetch('/api/dentists/documents', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.message || 'Ошибка загрузки');
      }

      const data = await response.json();
      
      if (documentType === 'profile') {
        setProfilePhotoUrl(data.url);
      } else if (documentType === 'certificate') {
        setCertificate({ name: file.name, type: file.type, dataUrl: data.url });
        saveDocumentToStorage(DOCUMENT_KEYS.certificate, { name: file.name, type: file.type, dataUrl: data.url });
      } else if (documentType === 'category') {
        setCategory({ name: file.name, type: file.type, dataUrl: data.url });
        saveDocumentToStorage(DOCUMENT_KEYS.category, { name: file.name, type: file.type, dataUrl: data.url });
      }

      if (onSuccess) onSuccess(data.url);
    } catch (error) {
      console.error('Upload error:', error);
      alert('Не удалось загрузить файл. Попробуйте снова.');
    } finally {
      event.target.value = '';
    }
  };

  const handleDocumentDelete = (
    setter: React.Dispatch<React.SetStateAction<DocumentData | null>>,
    storageKey: string
  ) => {
    setter(null);
    saveDocumentToStorage(storageKey, null);
  };

  const getSegmentColor = (segment: string) => {
    const colorMap: Record<string, { bg: string; text: string }> = {
      econom: { bg: '#9ca3af', text: '#ffffff' },
      comfort: { bg: '#fbbf24', text: '#000000' },
      optimum: { bg: '#10b981', text: '#ffffff' },
      premium: { bg: '#0ea5e9', text: '#ffffff' },
      luxury: { bg: '#8b5cf6', text: '#ffffff' },
    };
    
    return colorMap[segment] || { bg: '#f3f4f6', text: '#9ca3af' };
  };

  const rangesServiceId = (analyticsRow && String(analyticsRow.serviceId || '').trim() !== '')
    ? analyticsRow.serviceId
    : (serviceRows.find(r => String(r.serviceId || '').trim() !== '')?.serviceId || '');

  const almatyPriceForRanges = rangesServiceId
    ? getAlmatyPriceByServiceId(rangesServiceId, almatyPrices)
    : (almatyPrices.length > 0 ? almatyPrices[0] : undefined);

  const segmentConfig = getSegmentConfigWithRealRanges(almatyPriceForRanges);

  return (
    <div className="h-screen bg-gray-50 overflow-hidden flex flex-col">
      <header className="flex-none bg-white border-b px-6 py-4 flex justify-between items-center">
        <div className="flex items-baseline">
          <span className="text-2xl font-bold text-slate-800">Стоматолог кабинеті</span>
          <span className="text-lg italic font-light text-slate-500 ml-2">/ Кабинет дантиста</span>
        </div>
        <button type="button" style={unifiedButtonStyle} onClick={handleLogout}>
          <span className="text-sm">Шығу</span>
          <span className="text-xs ml-1">Выйти</span>
        </button>
      </header>

      <main className="flex-1 overflow-hidden">
        <div className="px-4 sm:px-8 py-6" style={{
          maxWidth: 1320,
          margin: '0 auto',
          height: '100%',
          overflow: 'visible',
          borderBottom: '1px solid #e5e7eb'
        }}>
          {/* Desktop view */}
          <div style={{
            display: windowWidth >= 1024 ? 'grid' : 'none',
            gridTemplateColumns: 'minmax(0, 1fr) 480px',
            gap: '24px',
            alignItems: 'start',
            minHeight: '100%',
            overflow: 'visible'
          }}>
            {/* Left column */}
            <div style={{
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
              minWidth: 0,
              paddingRight: '4px',
              height: '100%'
            }}>
              <div style={{ minWidth: 0 }}>
                <h2 className="font-bold text-gray-900 text-xl mb-2">
                  <span className="font-bold">Менің қызметтерім</span>
                  <span className="text-sm italic font-light text-gray-600 ml-1"> / Мои услуги</span>
                </h2>
              </div>

              <div
                className="mt-6 bg-white rounded-lg border border-gray-200 overflow-hidden"
                style={{
                  height: `${servicesHeight}px`,
                  display: 'flex',
                  flexDirection: 'column',
                  minWidth: 0,
                  marginBottom: '16px',
                  borderBottom: '1px solid #d1d5db',
                  flexShrink: 0
                }}
              >
                {/* Header table */}
                <div
                  ref={headerContainerRef}
                  style={{
                    flexShrink: 0,
                    width: '100%',
                    overflow: 'hidden',
                    paddingRight: `${scrollbarWidth}px`,
                    borderBottom: '1px solid #d1d5db'
                  }}
                >
                  <table className="w-full" style={{ tableLayout: 'fixed', borderCollapse: 'collapse', minWidth: 0 }}>
                    <colgroup>
                      <col style={{ width: columnWidths.service, minWidth: '200px' }} />
                      <col style={{ width: columnWidths.price, minWidth: '100px' }} />
                      <col style={{ width: columnWidths.segment, minWidth: '60px' }} />
                      <col style={{ width: columnWidths.promotion, minWidth: '100px' }} />
                      <col style={{ width: columnWidths.visibility, minWidth: '70px' }} />
                      <col style={{ width: columnWidths.payment, minWidth: '70px' }} />
                      <col style={{ width: columnWidths.delete, minWidth: '40px' }} />
                    </colgroup>
                    <thead>
                      <tr className="border-b border-gray-200 bg-gray-50">
                        <th style={{ height: '40px', verticalAlign: 'top', padding: '4px 16px 12px 16px' }} className="text-left font-medium text-gray-700">
                          <div style={{ fontSize: '13px', lineHeight: '1.2' }}>
                            <span className="font-bold">Қызмет</span>
                            <span className="text-xs italic font-light text-gray-600 ml-1"> / Услуги</span>
                          </div>
                        </th>
                        <th style={{ height: '40px', verticalAlign: 'top', padding: '4px 16px 12px 16px' }} className="text-right font-medium text-gray-700">
                          <div style={{ fontSize: '13px', lineHeight: '1.2' }}>Бағасы</div>
                          <div style={{ fontSize: '11px', lineHeight: '1.2', fontWeight: 'normal', color: '#6b7280' }}>ЦЕНА ₸</div>
                        </th>
                        <th style={{ height: '40px', verticalAlign: 'top', padding: '4px 16px 12px 16px' }} className="text-left font-medium text-gray-700">
                          <div style={{ fontSize: '13px', lineHeight: '1.2' }}>Сегмент</div>
                        </th>
                        <th style={{ height: '40px', verticalAlign: 'top', padding: '4px 16px 12px 16px' }} className="text-left font-medium text-gray-700">
                          <div style={{ fontSize: '13px', lineHeight: '1.2' }}>Көтеру / Поднять</div>
                        </th>
                        <th style={{ height: '40px', verticalAlign: 'top', padding: '4px 16px 12px 16px' }} className="text-left font-medium text-gray-700">
                          <div style={{ fontSize: '13px', lineHeight: '1.2' }}>Көріну</div>
                          <div style={{ fontSize: '11px', lineHeight: '1.2', fontWeight: 'normal', color: '#6b7280' }}>Видимость</div>
                        </th>
                        <th style={{ height: '40px', verticalAlign: 'top', padding: '4px 16px 12px 16px' }} className="text-right font-medium text-gray-700">
                          <div style={{ fontSize: '13px', lineHeight: '1.2' }}>Төлеу</div>
                          <div style={{ fontSize: '11px', lineHeight: '1.2', fontWeight: 'normal', color: '#6b7280' }}>Оплата</div>
                        </th>
                        <th style={{ height: '40px', verticalAlign: 'top', padding: '4px 16px 12px 16px', width: '40px' }} className="text-center font-medium text-gray-700">
                          <div style={{ fontSize: '13px', lineHeight: '1.2' }}></div>
                        </th>
                        </tr>
                    </thead>
                  </table>
                </div>

                {/* Body table */}
                <div
                  ref={bodyContainerRef}
                  style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', minWidth: 0, width: '100%' }}
                >
                  <table className="w-full" style={{ tableLayout: 'fixed', borderCollapse: 'collapse', minWidth: 0 }}>
                    <colgroup>
                      <col style={{ width: columnWidths.service, minWidth: '200px' }} />
                      <col style={{ width: columnWidths.price, minWidth: '100px' }} />
                      <col style={{ width: columnWidths.segment, minWidth: '60px' }} />
                      <col style={{ width: columnWidths.promotion, minWidth: '100px' }} />
                      <col style={{ width: columnWidths.visibility, minWidth: '70px' }} />
                      <col style={{ width: columnWidths.payment, minWidth: '70px' }} />
                      <col style={{ width: columnWidths.delete, minWidth: '40px' }} />
                    </colgroup>
                    <tbody>
                      {serviceRows.map((row) => {
                        const segment = row.segment || '';
                        const segmentColor = getSegmentColor(segment);
                        const localPrice = localPrices.get(row.id) ?? (row.price !== null ? String(row.price) : '');
                        
                        return (
                          <React.Fragment key={row.id + (nicheStatuses[row.id]?.price ?? "")}>
                            <tr
                              className={`border-b border-gray-100 hover:bg-gray-50 cursor-pointer ${activeService === row.id ? 'bg-blue-50' : ''}`}
                              onClick={() => handleServiceSelect(row.id)}
                            >
                              <td style={{ height: '48px', verticalAlign: 'middle', minWidth: '200px' }} className="p-4">
                                <div style={{ fontSize: '12px', fontWeight: '500', marginBottom: '4px', display: 'flex', alignItems: 'flex-start', justifyContent: 'flex-start' }}>
                                  {getServiceNameRU(row.serviceId)}
                                </div>
                                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'flex-start' }}>
                                  <select
                                    style={{
                                      width: '100%',
                                      maxWidth: '220px',
                                      height: '28px',
                                      border: '1px solid #d1d5db',
                                      borderRadius: '4px',
                                      padding: '0 8px',
                                      fontSize: '12px',
                                      backgroundColor: '#ffffff'
                                    }}
                                    value={row.serviceId}
                                    onClick={(e) => e.stopPropagation()}
                                    onChange={(e) => updateServiceRow(row.id, e.target.value)}
                                  >
                                    <option value="">Выберите услугу</option>
                                    {Object.entries(groupedServices).map(([category, services]) => (
                                      <optgroup key={category} label={category}>
                                        {services.map((service) => (
                                          <option key={service.id} value={service.id}>
                                            {service.nameRU}
                                          </option>
                                        ))}
                                      </optgroup>
                                    ))}
                                  </select>
                                </div>
                              </td>
                              <td style={{ height: '48px', verticalAlign: 'middle', minWidth: '80px' }} className="p-4 text-right">
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', width: '100%', height: '100%' }}>
                                  <input
                                    type="text"
                                    value={localPrice}
                                    onChange={(e) => {
                                      const val = e.target.value;
                                      setLocalPrices(prev => new Map(prev).set(row.id, val));
                                      
                                      const existingTimeout = priceTimeoutRef.current.get(row.id);
                                      if (existingTimeout) clearTimeout(existingTimeout);
                                      
                                      const timeout = setTimeout(() => {
                                        const cleanVal = val.replace(/\D/g, '');
                                        updateServicePrice(row.id, cleanVal);
                                      }, 1000);
                                      priceTimeoutRef.current.set(row.id, timeout);
                                    }}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        e.preventDefault();
                                        const val = localPrices.get(row.id) ?? (row.price !== null ? String(row.price) : '');
                                        const cleanVal = val.replace(/\D/g, '');
                                        const existingTimeout = priceTimeoutRef.current.get(row.id);
                                        if (existingTimeout) clearTimeout(existingTimeout);
                                        updateServicePrice(row.id, cleanVal);
                                      }
                                    }}
                                    onClick={(e) => e.stopPropagation()}
                                    style={{
                                      width: '100%',
                                      height: '24px',
                                      border: '1px solid #d1d5db',
                                      borderRadius: '4px',
                                      padding: '0 4px',
                                      textAlign: 'right',
                                      fontSize: '10px',
                                      fontWeight: '500',
                                      backgroundColor: '#ffffff'
                                    }}
                                    placeholder="Введите стоимость"
                                    disabled={false}
                                  />
                                </div>
                              </td>
                              <td style={{ height: '48px', verticalAlign: 'middle', minWidth: '80px' }} className="p-4">
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', height: '100%' }}>
                                  <div
                                    style={{
                                      minWidth: '96px',
                                      height: '32px',
                                      lineHeight: '32px',
                                      textAlign: 'center',
                                      borderRadius: '8px',
                                      fontSize: '12px',
                                      fontWeight: '500',
                                      padding: '0 12px',
                                      border: '1px solid transparent',
                                      backgroundColor: segmentColor.bg,
                                      color: segmentColor.text,
                                      margin: '0 auto',
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      justifyContent: 'center'
                                    }}
                                  >
                                    {segment ? segment : ''}
                                  </div>
                                </div>
                              </td>
                              <td style={{ height: '48px', verticalAlign: 'middle', minWidth: '100px' }} className="p-4">
                                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'flex-start', flexDirection: 'column', width: '100%' }}>
                                  <select
                                    style={{
                                      width: '100%',
                                      border: '1px solid #d1d5db',
                                      borderRadius: '4px',
                                      padding: '4px 8px',
                                      fontSize: '12px',
                                      marginBottom: '4px',
                                      height: '24px'
                                    }}
                                    value={row.radiusKm}
                                    onClick={(e) => e.stopPropagation()}
                                    onChange={(e) => {
                                      const value = e.target.value;
                                      if (value === 'city') {
                                        updateServiceRadius(row.id, 'city');
                                      } else {
                                        updateServiceRadius(row.id, parseInt(value) as 1 | 3 | 6);
                                      }
                                    }}
                                  >
                                    <option value="city">Город (city)</option>
                                    <option value="1">1 км</option>
                                    <option value="3">3 км</option>
                                    <option value="6">6 км</option>
                                  </select>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '4px', width: '100%', justifyContent: 'space-between' }}>
                                    <div style={{ fontSize: '12px', fontWeight: '500', color: '#111827' }}>
                                      {(() => {
                                        const dynamic = nicheStatuses[row.id];
                                        if (dynamic) {
                                          return dynamic.price.toLocaleString('ru-RU') + ' ₸';
                                        }
                                        const multiplier = promotionPrices[segment]?.[String(row.radiusKm)];
                                        if (multiplier && row.price) {
                                          return Math.round(row.price * multiplier).toLocaleString('ru-RU') + ' ₸';
                                        }
                                        return '';
                                      })()}
                                    </div>
                                    {nicheStatuses[row.id] && (
                                      <div
                                        style={{
                                          width: '10px',
                                          height: '10px',
                                          borderRadius: '50%',
                                          backgroundColor:
                                            nicheStatuses[row.id].status === 'green' ? '#22c55e' :
                                            nicheStatuses[row.id].status === 'yellow' ? '#eab308' :
                                            '#ef4444',
                                        }}
                                        title={
                                          nicheStatuses[row.id].status === 'green' ? 'свободно' :
                                          nicheStatuses[row.id].status === 'yellow' ? 'вытеснение' : 'активно'
                                        }
                                      />
                                    )}
                                  </div>
                                </div>
                              </td>
                              <td style={{ height: '48px', verticalAlign: 'middle', minWidth: '80px' }} className="p-4">
                                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', width: '100%', height: '100%' }}>
                                  <div className="flex items-center gap-2">
                                    {row.isPaid ? (
                                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2">
                                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                        <circle cx="12" cy="12" r="3" />
                                      </svg>
                                    ) : (
                                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2">
                                        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
                                        <line x1="1" y1="1" x2="23" y2="23" />
                                      </svg>
                                    )}
                                  </div>
                                </div>
                              </td>
                              <td style={{ height: '48px', verticalAlign: 'middle', minWidth: '60px' }} className="p-4 text-right">
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', width: '100%', height: '100%' }}>
                                  <button
                                    className={`flex items-center justify-center border ${row.price === null ? 'border-gray-300 text-gray-300 cursor-not-allowed' : row.isPaid ? 'border-gray-300 text-gray-500' : 'border-blue-500 text-blue-500 hover:bg-blue-50'} ml-auto`}
                                    style={{ width: '28px', height: '28px', borderRadius: '8px' }}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (row.price === null) return;
                                      if (row.isPaid) {
                                        handleEvictService(row.id, 0, 0);
                                      } else {
                                        handlePayService(row.id);
                                      }
                                    }}
                                    disabled={row.price === null}
                                  >
                                    <div style={{ width: '16px', height: '16px' }}>
                                      <svg viewBox="0 0 24 24" width="16" height="16" className="fill-current">
                                        <path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94.2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z" />
                                      </svg>
                                    </div>
                                  </button>
                                </div>
                              </td>
                              <td style={{ height: '48px', verticalAlign: 'middle', width: '40px', minWidth: '40px' }} className="p-4 text-center">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setServiceRows(prev => prev.filter(r => r.id !== row.id));
                                    setLocalPrices(prev => {
                                      const newMap = new Map(prev);
                                      newMap.delete(row.id);
                                      return newMap;
                                    });
                                  }}
                                  style={{
                                    width: '24px',
                                    height: '24px',
                                    borderRadius: '50%',
                                    border: 'none',
                                    backgroundColor: '#e5e7eb',
                                    color: '#4b5563',
                                    fontSize: '16px',
                                    fontWeight: 'bold',
                                    cursor: 'pointer',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                  }}
                                  title="Удалить услугу"
                                >
                                  ×
                                </button>
                              </td>
                            </tr>
                          </React.Fragment>
                        );
                      })}
                      
                      <tr>
                        <td colSpan={7} className="p-4" style={{ verticalAlign: 'top' }}>
                          <button
                            onClick={handleAddServiceRow}
                            style={{
                              height: '24px',
                              width: '24px',
                              borderRadius: '6px',
                              border: '1px solid #d1d5db',
                              background: '#fff',
                              cursor: 'pointer',
                              display: 'inline-flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              color: '#000000'
                            }}
                          >
                            +
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Resizer */}
              <div
                style={{
                  height: '12px',
                  backgroundColor: '#f3f4f6',
                  borderTop: '1px solid #d1d5db',
                  borderBottom: '1px solid #d1d5db',
                  cursor: 'row-resize',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  position: 'relative',
                  margin: '4px 0',
                  flexShrink: 0
                }}
                onMouseDown={handleMouseDown}
              >
                <div style={{ display: 'flex', gap: '2px' }}>
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={i}
                      style={{
                        width: '4px',
                        height: '4px',
                        borderRadius: '50%',
                        backgroundColor: '#9ca3af'
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Analytics and status block */}
              <div style={{ overflow: 'visible', display: 'flex', flexDirection: 'column', minWidth: 0, paddingTop: '20px', borderTop: '1px solid #d1d5db' }}>
                <div className="bg-white rounded-lg border border-gray-200 p-4" style={{ overflowY: 'visible', overflowX: 'hidden', flexShrink: 0, minWidth: 0 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '8px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'nowrap', gap: '12px', minWidth: 0, overflowX: 'hidden' }}>
                      <h3 className="font-medium text-gray-900 text-sm">
                        <span className="font-bold">Қызмет аналитикасы</span>
                        <span className="text-xs italic font-light text-gray-600 ml-1"> / Аналитика по услуге</span>
                      </h3>
                      <div style={{ display: 'flex', flexWrap: 'nowrap', gap: '6px', justifyContent: 'flex-end', minWidth: 0, flex: '1 1 auto', flexShrink: 1, whiteSpace: 'nowrap', maxWidth: '100%', overflowX: 'hidden' }}>
                        {segmentConfig.map((cfg: any) => {
                          const SEGMENT_COLORS: Record<'econom'|'comfort'|'optimum'|'premium'|'luxury', { bg: string; text: string }> = {
                            econom:  { bg: '#9ca3af', text: '#ffffff' },
                            comfort: { bg: '#fbbf24', text: '#000000' },
                            optimum: { bg: '#10b981', text: '#ffffff' },
                            premium: { bg: '#0ea5e9', text: '#ffffff' },
                            luxury:  { bg: '#8b5cf6', text: '#ffffff' },
                          };
                          const segColor = SEGMENT_COLORS[cfg.key as keyof typeof SEGMENT_COLORS];
                          const getPriceText = () => {
                            if (!almatyPriceForRanges) return '';
                            if (cfg.key === 'econom' && Number.isFinite(almatyPriceForRanges.econom)) return `до ${Number(almatyPriceForRanges.econom).toLocaleString('ru-RU')} ₸`;
                            if (cfg.key === 'comfort' && Number.isFinite(almatyPriceForRanges.comfort)) return `до ${Number(almatyPriceForRanges.comfort).toLocaleString('ru-RU')} ₸`;
                            if (cfg.key === 'optimum' && Number.isFinite(almatyPriceForRanges.optimum)) return `до ${Number(almatyPriceForRanges.optimum).toLocaleString('ru-RU')} ₸`;
                            if (cfg.key === 'premium' && Number.isFinite(almatyPriceForRanges.premium)) return `до ${Number(almatyPriceForRanges.premium).toLocaleString('ru-RU')} ₸`;
                            if (cfg.key === 'luxury' && Number.isFinite(almatyPriceForRanges.luxury)) return `от ${Number(almatyPriceForRanges.luxury).toLocaleString('ru-RU')} ₸`;
                            return '';
                          };
                          const priceText = getPriceText();
                          return (
                            <div
                              key={cfg.key}
                              style={{
                                background: segColor.bg,
                                border: '1px solid #e5e7eb',
                                borderRadius: '6px',
                                padding: '4px 6px',
                                fontSize: '12px',
                                color: segColor.text,
                                whiteSpace: 'nowrap',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                minWidth: '0px',
                                flex: '0 1 auto',
                                flexShrink: 1
                              }}
                            >
                              <div style={{ fontWeight: '600', marginBottom: '2px' }}>{String(cfg.name || '').toUpperCase()}</div>
                              {priceText && <div style={{ fontSize: '10px', color: '#000000', fontWeight: '500', lineHeight: '1.2' }}>{priceText}</div>}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  <div className="mb-4 flex items-center gap-3 flex-wrap">
                    <select
                      className={`${inputBase} bg-white`}
                      style={{ width: 'auto', minWidth: '200px', maxWidth: '300px' }}
                      value={analyticsRowId || ''}
                      onChange={(e) => { setAnalyticsRowId(e.target.value); setActiveService(e.target.value); }}
                    >
                      {serviceRows.map((row) => (
                        <option key={row.id} value={row.id}>{getServiceDisplayName(row.id)}</option>
                      ))}
                    </select>

                    {analyticsRow && nicheStatuses?.[analyticsRow.id] && (
                      <div className="flex items-center gap-2 p-1 border border-gray-200 rounded">
                        <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: nicheStatuses[analyticsRow.id].status === 'green' ? '#22c55e' : nicheStatuses[analyticsRow.id].status === 'yellow' ? '#eab308' : '#ef4444' }} />
                        <span className="text-xs font-medium">
                          {nicheStatuses[analyticsRow.id].status === 'green' ? 'свободно' : nicheStatuses[analyticsRow.id].status === 'yellow' ? 'вытеснение' : 'активно'}
                        </span>
                        <span className="text-sm font-bold ml-1">{nicheStatuses[analyticsRow.id].price.toLocaleString('ru-RU')} ₸</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <table className="w-full border-collapse" style={{ minWidth: 0 }}>
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th style={{ verticalAlign: 'top', fontSize: '12px', padding: '8px' }}>Спрос<br />на услугу</th>
                          <th style={{ verticalAlign: 'top', fontSize: '12px', padding: '8px' }}>Всего<br />просмотры (город)</th>
                          <th style={{ verticalAlign: 'top', fontSize: '12px', padding: '8px' }}>Ваш<br />сегмент</th>
                          <th style={{ verticalAlign: 'top', fontSize: '12px', padding: '8px' }}>1 км</th>
                          <th style={{ verticalAlign: 'top', fontSize: '12px', padding: '8px' }}>3 км</th>
                          <th style={{ verticalAlign: 'top', fontSize: '12px', padding: '8px' }}>6 км</th>
                          <th style={{ verticalAlign: 'top', fontSize: '12px', padding: '8px' }}>WhatsApp<br />переходы</th>
                         </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-gray-100">
                          <td style={{ verticalAlign: 'top', fontSize: '14px', lineHeight: '20px', padding: '8px' }}>{analyticsRow ? analyticsRow.viewsCity?.toLocaleString('ru-RU') ?? '0' : ''}</td>
                          <td style={{ verticalAlign: 'top', fontSize: '14px', lineHeight: '20px', padding: '8px' }}>{analyticsRow ? ((analyticsRow.views1km || 0) + (analyticsRow.views3km || 0) + (analyticsRow.views6km || 0) + (analyticsRow.viewsCity || 0)).toLocaleString('ru-RU') : ''}</td>
                          <td style={{ verticalAlign: 'top', fontSize: '14px', lineHeight: '20px', padding: '8px' }}>{analyticsRow && analyticsRow.price !== null ? (analyticsRow.segment || '') : ''}</td>
                          <td style={{ verticalAlign: 'top', fontSize: '14px', lineHeight: '20px', padding: '8px' }}>{analyticsRow ? analyticsRow.views1km?.toLocaleString('ru-RU') ?? '0' : ''}</td>
                          <td style={{ verticalAlign: 'top', fontSize: '14px', lineHeight: '20px', padding: '8px' }}>{analyticsRow ? analyticsRow.views3km?.toLocaleString('ru-RU') ?? '0' : ''}</td>
                          <td style={{ verticalAlign: 'top', fontSize: '14px', lineHeight: '20px', padding: '8px' }}>{analyticsRow ? analyticsRow.views6km?.toLocaleString('ru-RU') ?? '0' : ''}</td>
                          <td style={{ verticalAlign: 'top', fontSize: '14px', lineHeight: '20px', padding: '8px' }}>{analyticsRow ? analyticsRow.whatsappClicks?.toLocaleString('ru-RU') ?? '0' : ''}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="bg-white rounded-lg border border-gray-200 p-4" style={{ overflowY: 'visible', minWidth: 0, backgroundColor: '#f9fafb' }}>
                  <div style={{ height: '1px', backgroundColor: '#3b82f6', width: '100%', marginTop: '8px', marginBottom: '8px' }} />
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                    <h3 className="font-medium text-gray-900 text-sm">
                      <span className="font-bold">Мәртебе</span>
                      <span className="text-xs italic font-light text-gray-600 ml-1"> / Статус</span>
                    </h3>
                    <button className={`${buttonBase} border-gray-300 bg-white hover:bg-gray-50`}>Есептер / Отчёты</button>
                  </div>
                  <div>
                    {(() => {
                      const activePaidServices = getActivePaidServices();
                      if (activePaidServices.length === 0) return null;
                      return (
                        <div style={{ maxHeight: '180px', overflowY: 'visible', overflowX: 'hidden', paddingRight: '6px', textAlign: 'left', verticalAlign: 'top' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                            {activePaidServices.map((row) => (
                              <div key={row.id} style={{ border: '1px solid #e5e7eb', borderRadius: '8px', padding: '16px', backgroundColor: '#f9fafb' }}>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', alignItems: 'flex-start' }}>
                                  <div style={{ fontSize: '14px', fontWeight: '500', color: '#111827', textAlign: 'left', lineHeight: '1.4' }}>
                                    Вашу услугу <strong>"{getServiceDisplayName(row.id)}"</strong> видят в радиусе <strong>{row.radiusKm} км</strong> в сегменте <strong>{row.segment}</strong>.
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>
            </div>

            {/* Right column - Profile */}
            <div className="w-[480px]" style={{ width: 480, justifySelf: "end", overflowY: 'visible', overflowX: 'hidden', borderBottom: '1px solid #e5e7eb', paddingBottom: '8px' }}>
              <h2 className="font-bold text-gray-900 text-xl mb-2">
                <span className="font-bold">Менің профилім</span>
                <span className="text-sm italic font-light text-gray-600 ml-1"> / Мой профиль</span>
              </h2>

              <div className="bg-white rounded-xl border border-gray-200 p-3">
                <div className="mb-2">
                  <div className="text-xs font-medium text-gray-700 mb-1">ФИО</div>
                  <input type="text" value={profileFullName} onChange={(e) => setProfileFullName(e.target.value)} className="w-full h-7 rounded-md border px-2 text-xs leading-5" placeholder="Введите ФИО" />
                  <div className="flex justify-start mt-1">
                    <button style={unifiedButtonStyle} onClick={handleSaveProfile}>Save</button>
                  </div>
                </div>
                <div className="mb-2">
                  <div className="text-xs font-medium text-gray-700 mb-1">Фото</div>
                  <div className="flex items-center gap-3">
                    <div style={{ width: 64, height: 64, flex: '0 0 64px' }}>
                      <img src={profilePhotoUrl} alt="Doctor" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '8px' }} />
                    </div>
                    <div className="flex gap-2">
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={(e) => handleDocumentUpload(e, 'profile', (url) => setProfilePhotoUrl(url))} 
                        style={{ display: 'none' }} 
                        id="profile-photo-input"
                      />
                      <label htmlFor="profile-photo-input" style={unifiedButtonStyle}>
                        <span className="flex items-center gap-1">
                          <svg viewBox="0 0 24 24" width="14" height="14" className="fill-current"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z" /></svg>
                          Upload
                        </span>
                      </label>
                      <button onClick={() => setProfilePhotoUrl(doctorPhotoUrl)} style={unifiedButtonStyle}>Delete</button>
                    </div>
                  </div>
                </div>
                <div className="mb-2">
                  <div className="text-xs font-medium text-gray-700 mb-1">WhatsApp</div>
                  <input type="tel" value={profileWhatsapp} onChange={(e) => setProfileWhatsapp(e.target.value)} className="w-full h-7 rounded-md border px-2 text-xs leading-5" placeholder="+7 (___) ___ __-__" />
                  <div className="flex justify-start mt-1">
                    <button style={unifiedButtonStyle} onClick={handleSaveProfile}>Save</button>
                  </div>
                </div>
                <div className="mb-2">
                  <div className="text-xs font-medium text-gray-700 mb-1">Адрес</div>
                  <input type="text" value={profileAddress} onChange={(e) => setProfileAddress(e.target.value)} className="w-full h-7 rounded-md border px-2 text-xs leading-5" placeholder="Введите адрес оказания услуг" />
                  <div className="flex justify-start mt-1">
                    <button style={unifiedButtonStyle} onClick={handleSaveProfile}>Save</button>
                  </div>
                </div>
                <div className="mt-3">
                  <h3 className="font-medium text-gray-900 text-xs mb-2">
                    <span className="font-bold">ҚҰЖАТТАР</span>
                    <span className="text-[10px] italic font-light text-gray-600 ml-1"> / ДОКУМЕНТЫ</span>
                  </h3>
                  <div className="space-y-2">
                    <div>
                      <div className="text-xs text-gray-700 mb-1">Сертификат</div>
                      <div className="flex gap-2">
                        <input 
                          type="file" 
                          accept="image/*,.pdf" 
                          onChange={(e) => handleDocumentUpload(e, 'certificate')} 
                          style={{ display: 'none' }} 
                          id="certificate-input"
                        />
                        <label htmlFor="certificate-input" style={unifiedButtonStyle}>
                          <span className="flex items-center gap-1">
                            <svg viewBox="0 0 24 24" width="14" height="14" className="fill-current"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z" /></svg>
                            Upload
                          </span>
                        </label>
                        <button onClick={() => handleDocumentDelete(setCertificate, DOCUMENT_KEYS.certificate)} style={unifiedButtonStyle}>Delete</button>
                      </div>
                      {certificate && <div className="text-xs text-green-600 mt-1">{certificate.name}</div>}
                    </div>
                    <div>
                      <div className="text-xs text-gray-700 mb-1">Категория</div>
                      <div className="flex gap-2">
                        <input 
                          type="file" 
                          accept="image/*,.pdf" 
                          onChange={(e) => handleDocumentUpload(e, 'category')} 
                          style={{ display: 'none' }} 
                          id="category-input"
                        />
                        <label htmlFor="category-input" style={unifiedButtonStyle}>
                          <span className="flex items-center gap-1">
                            <svg viewBox="0 0 24 24" width="14" height="14" className="fill-current"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z" /></svg>
                            Upload
                          </span>
                        </label>
                        <button onClick={() => handleDocumentDelete(setCategory, DOCUMENT_KEYS.category)} style={unifiedButtonStyle}>Delete</button>
                      </div>
                      {category && <div className="text-xs text-green-600 mt-1">{category.name}</div>}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile view */}
          <div style={{
            height: '100%',
            width: '100%',
            maxWidth: '100%',
            display: windowWidth < 1024 ? 'flex' : 'none',
            flexDirection: 'column',
            overflowX: 'hidden',
            padding: '0'
          }}>
            <div style={{ display: 'flex', borderBottom: '1px solid #e5e7eb', marginBottom: '12px' }}>
              <button
                style={{
                  flex: 1,
                  padding: '10px 0',
                  textAlign: 'center',
                  fontSize: '14px',
                  borderBottom: activeTab === 'services' ? '2px solid #3b82f6' : 'none',
                  fontWeight: activeTab === 'services' ? '600' : '400',
                  color: activeTab === 'services' ? '#000' : '#6b7280'
                }}
                onClick={() => setActiveTab('services')}
              >
                Услуги
              </button>
              <button
                style={{
                  flex: 1,
                  padding: '10px 0',
                  textAlign: 'center',
                  fontSize: '14px',
                  borderBottom: activeTab === 'profile' ? '2px solid #3b82f6' : 'none',
                  fontWeight: activeTab === 'profile' ? '600' : '400',
                  color: activeTab === 'profile' ? '#000' : '#6b7280'
                }}
                onClick={() => setActiveTab('profile')}
              >
                Профиль
              </button>
              <button
                style={{
                  flex: 1,
                  padding: '10px 0',
                  textAlign: 'center',
                  fontSize: '14px',
                  borderBottom: activeTab === 'reports' ? '2px solid #3b82f6' : 'none',
                  fontWeight: activeTab === 'reports' ? '600' : '400',
                  color: activeTab === 'reports' ? '#000' : '#6b7280'
                }}
                onClick={() => setActiveTab('reports')}
              >
                Отчёты
              </button>
            </div>

            <div style={{ flex: 1, overflowY: 'auto', padding: '0 12px' }}>
              {activeTab === 'services' && (
                <div>
                  <h2 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '12px' }}>Мои услуги</h2>

                  <div className="mb-4 border border-gray-200 rounded-lg p-3 bg-white">
                    <div className="mb-2">
                      <div className="text-xs font-medium text-gray-700 mb-1">Услуга</div>
                      <select
                        value={tempServiceId}
                        onChange={(e) => setTempServiceId(e.target.value)}
                        className="w-full border rounded px-2 py-2 text-sm"
                      >
                        <option value="">Выберите услугу</option>
                        {Object.entries(groupedServices).map(([category, services]) => (
                          <optgroup key={category} label={category}>
                            {services.map((service) => (
                              <option key={service.id} value={service.id}>
                                {service.nameRU} / {service.nameKZ}
                              </option>
                            ))}
                          </optgroup>
                        ))}
                      </select>
                    </div>

                    <div className="flex gap-2 mb-2">
                      <div className="flex-1">
                        <div className="text-xs font-medium text-gray-700 mb-1">Цена (₸)</div>
                        <input
                          type="text"
                          value={tempPrice ?? ''}
                          onChange={(e) => {
                            const cleanVal = e.target.value.replace(/\D/g, '');
                            setTempPrice(cleanVal === '' ? null : Number(cleanVal));
                          }}
                          className="w-full border rounded px-2 py-2 text-sm"
                          placeholder="0"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs font-medium text-gray-700 mb-1">Радиус</div>
                        <select
                          value={tempRadius}
                          onChange={(e) => {
                            const value = e.target.value;
                            if (value === 'city') {
                              setTempRadius('city');
                            } else {
                              setTempRadius(Number(value) as 1 | 3 | 6);
                            }
                          }}
                          className="w-full border rounded px-2 py-2 text-sm"
                        >
                          <option value="city">Город (city)</option>
                          <option value="1">1 км</option>
                          <option value="3">3 км</option>
                          <option value="6">6 км</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-xs font-medium text-gray-700 mb-1">Сегмент</div>
                        <div
                          className="px-3 py-1 rounded text-xs font-medium inline-block"
                          style={{
                            backgroundColor: (tempServiceId && tempPrice !== null) ? getSegmentColor(getSegment(tempPrice, tempServiceId)).bg : '#f3f4f6',
                            color: (tempServiceId && tempPrice !== null) ? getSegmentColor(getSegment(tempPrice, tempServiceId)).text : '#9ca3af'
                          }}
                        >
                          {(tempServiceId && tempPrice !== null) ? getSegment(tempPrice, tempServiceId) : '—'}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs font-medium text-gray-700 mb-1">Стоимость</div>
                        <span className="text-sm font-bold">
                          {tempServiceId && tempPrice !== null && tempRadius
                            ? (() => {
                                const segment = getSegment(tempPrice, tempServiceId);
                                const multiplier = promotionPrices[segment]?.[String(tempRadius)];
                                if (multiplier) {
                                  return Math.round(tempPrice * multiplier).toLocaleString('ru-RU') + ' ₸';
                                }
                                return '0 ₸';
                              })()
                            : '0 ₸'}
                        </span>
                      </div>
                      <button
                        onClick={handleAddTempRow}
                        className="w-10 h-10 bg-blue-500 text-white rounded-lg flex items-center justify-center text-2xl"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div style={{ marginBottom: '20px' }}>
                    {serviceRows.map((row) => {
                      const segment = row.segment || '';
                      const segmentColor = getSegmentColor(segment);
                      const localPrice = localPrices.get(row.id) ?? (row.price !== null ? String(row.price) : '');
                      
                      return (
                        <div
                          key={row.id}
                          style={{
                            border: '1px solid #e5e7eb',
                            borderRadius: '12px',
                            padding: '16px',
                            marginBottom: '16px',
                            backgroundColor: row.isPaid ? '#f0fdf4' : '#ffffff',
                            position: 'relative'
                          }}
                        >
                          <button
                            onClick={() => {
                              setServiceRows(prev => prev.filter(r => r.id !== row.id));
                              setLocalPrices(prev => {
                                const newMap = new Map(prev);
                                newMap.delete(row.id);
                                return newMap;
                              });
                            }}
                            style={{
                              position: 'absolute',
                              top: '8px',
                              right: '8px',
                              width: '24px',
                              height: '24px',
                              borderRadius: '50%',
                              border: 'none',
                              backgroundColor: '#e5e7eb',
                              color: '#4b5563',
                              fontSize: '16px',
                              fontWeight: 'bold',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center'
                            }}
                          >
                            ×
                          </button>

                          <div style={{ marginBottom: '12px', paddingRight: '30px' }}>
                            <div style={{ fontWeight: '600', fontSize: '16px', marginBottom: '4px' }}>
                              {getServiceNameRU(row.serviceId) || 'Выберите услугу'}
                            </div>
                            <select
                              style={{
                                width: '100%',
                                height: '36px',
                                border: '1px solid #d1d5db',
                                borderRadius: '6px',
                                padding: '0 8px',
                                fontSize: '14px',
                                backgroundColor: '#ffffff'
                              }}
                              value={row.serviceId}
                              onClick={(e) => e.stopPropagation()}
                              onChange={(e) => updateServiceRow(row.id, e.target.value)}
                            >
                              <option value="">Выберите услугу</option>
                              {Object.entries(groupedServices).map(([category, services]) => (
                                <optgroup key={category} label={category}>
                                  {services.map((service) => (
                                    <option key={service.id} value={service.id}>
                                      {service.nameRU}
                                    </option>
                                  ))}
                                </optgroup>
                              ))}
                            </select>
                          </div>

                          <div style={{ marginBottom: '12px' }}>
                            <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Цена (₸)</div>
                            <input
                              type="text"
                              value={localPrice}
                              onChange={(e) => {
                                const val = e.target.value;
                                setLocalPrices(prev => new Map(prev).set(row.id, val));
                                
                                const existingTimeout = priceTimeoutRef.current.get(row.id);
                                if (existingTimeout) clearTimeout(existingTimeout);
                                
                                const timeout = setTimeout(() => {
                                  const cleanVal = val.replace(/\D/g, '');
                                  updateServicePrice(row.id, cleanVal);
                                }, 1000);
                                priceTimeoutRef.current.set(row.id, timeout);
                              }}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  const val = localPrices.get(row.id) ?? (row.price !== null ? String(row.price) : '');
                                  const cleanVal = val.replace(/\D/g, '');
                                  const existingTimeout = priceTimeoutRef.current.get(row.id);
                                  if (existingTimeout) clearTimeout(existingTimeout);
                                  updateServicePrice(row.id, cleanVal);
                                }
                              }}
                              style={{
                                width: '100%',
                                height: '40px',
                                border: '1px solid #d1d5db',
                                borderRadius: '6px',
                                padding: '0 12px',
                                fontSize: '15px',
                                boxSizing: 'border-box'
                              }}
                              placeholder="0"
                            />
                          </div>

                          <div style={{ marginBottom: '12px' }}>
                            <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Сегмент</div>
                            <div
                              style={{
                                width: '100%',
                                height: '40px',
                                lineHeight: '40px',
                                textAlign: 'center',
                                borderRadius: '6px',
                                fontSize: '14px',
                                fontWeight: '500',
                                backgroundColor: segmentColor.bg,
                                color: segmentColor.text
                              }}
                            >
                              {segment || '—'}
                            </div>
                          </div>

                          <div style={{ marginBottom: '12px' }}>
                            <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Радиус</div>
                            <div style={{ display: 'flex', gap: '8px' }}>
                              {['city', 1, 3, 6].map((km) => (
                                <button
                                  key={km}
                                  onClick={() => updateServiceRadius(row.id, km as 1 | 3 | 6 | 'city')}
                                  style={{
                                    flex: 1,
                                    height: '40px',
                                    border: row.radiusKm === km ? '2px solid #2563eb' : '1px solid #d1d5db',
                                    borderRadius: '6px',
                                    backgroundColor: row.radiusKm === km ? '#dbeafe' : '#ffffff',
                                    color: row.radiusKm === km ? '#1e40af' : '#374151',
                                    fontWeight: row.radiusKm === km ? '600' : '400',
                                    cursor: 'pointer'
                                  }}
                                >
                                  {km === 'city' ? 'Город' : `${km} км`}
                                </button>
                              ))}
                            </div>
                          </div>

                          <div style={{ marginBottom: '16px', textAlign: 'right' }}>
                            <span style={{ fontSize: '18px', fontWeight: 'bold' }}>
                              {(() => {
                                const dynamic = nicheStatuses[row.id];
                                if (dynamic) {
                                  return dynamic.price.toLocaleString('ru-RU') + ' ₸';
                                }
                                const multiplier = promotionPrices[segment]?.[String(row.radiusKm)];
                                if (multiplier && row.price) {
                                  return Math.round(row.price * multiplier).toLocaleString('ru-RU') + ' ₸';
                                }
                                return '0';
                              })()}
                            </span>
                            <span style={{ fontSize: '13px', color: '#6b7280', marginLeft: '4px' }}>за продвижение</span>
                          </div>

                          {nicheStatuses[row.id] && (
                            <div style={{ marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px', justifyContent: 'flex-end' }}>
                              <div
                                style={{
                                  width: '12px',
                                  height: '12px',
                                  borderRadius: '50%',
                                  backgroundColor:
                                    nicheStatuses[row.id].status === 'green' ? '#22c55e' :
                                    nicheStatuses[row.id].status === 'yellow' ? '#eab308' :
                                    '#ef4444',
                                }}
                              />
                              <span style={{ fontSize: '12px', fontWeight: '500', color: '#374151' }}>
                                {nicheStatuses[row.id].status === 'green' ? 'Свободно' :
                                 nicheStatuses[row.id].status === 'yellow' ? 'Вытеснение' : 'Активно'}
                              </span>
                            </div>
                          )}

                          {row.price !== null && (
                            <button
                              onClick={() => {
                                if (row.isPaid) {
                                  handleEvictService(row.id, row.views1km || 0, row.whatsappClicks || 0);
                                } else {
                                  handlePayService(row.id);
                                }
                              }}
                              style={{
                                width: '100%',
                                height: '48px',
                                borderRadius: '8px',
                                border: 'none',
                                backgroundColor: row.isPaid ? '#f59e0b' : '#2563eb',
                                color: '#ffffff',
                                fontSize: '16px',
                                fontWeight: '600',
                                cursor: 'pointer'
                              }}
                            >
                              {row.isPaid ? 'Вытеснить' : 'Оплатить продвижение'}
                            </button>
                          )}

                          {row.isPaid && row.paidAt && (
                            <div style={{ fontSize: '12px', color: '#059669', textAlign: 'center', marginTop: '8px' }}>
                              Оплачено: {new Date(row.paidAt).toLocaleDateString()}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <button
                    onClick={handleAddServiceRow}
                    style={{
                      width: '100%',
                      height: '48px',
                      border: '2px dashed #9ca3af',
                      borderRadius: '12px',
                      backgroundColor: '#ffffff',
                      fontSize: '16px',
                      color: '#374151',
                      marginBottom: '24px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px'
                    }}
                  >
                    <span style={{ fontSize: '24px', fontWeight: '400' }}>+</span>
                    <span>Добавить услугу</span>
                  </button>

                  <div style={{ 
                    height: '4px', 
                    backgroundColor: '#3b82f6', 
                    width: '100%', 
                    margin: '24px 0' 
                  }} />

                  <div style={{ marginBottom: '24px' }}>
                    <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '16px' }}>Аналитика</h3>

                    <div style={{ marginBottom: '20px' }}>
                      <select
                        style={{
                          width: '100%',
                          height: '40px',
                          border: '1px solid #d1d5db',
                          borderRadius: '8px',
                          padding: '0 12px',
                          fontSize: '14px',
                          backgroundColor: '#ffffff'
                        }}
                        value={analyticsRowId || ''}
                        onChange={(e) => {
                          const selectedId = e.target.value;
                          setAnalyticsRowId(selectedId);
                          setActiveService(selectedId);
                        }}
                      >
                        <option value="">Выберите услугу</option>
                        {serviceRows.map((row) => (
                          <option key={row.id} value={row.id}>
                            {getServiceDisplayName(row.id)}
                          </option>
                        ))}
                      </select>
                    </div>

                    {analyticsRow && (
                      <div style={{ marginBottom: '20px' }}>
                        <div style={{ 
                          display: 'flex', 
                          flexDirection: 'column',
                          gap: '12px',
                          width: '100%'
                        }}>
                          {segmentConfig.map((cfg: any) => {
                            const colors: Record<string, { bg: string; text: string }> = {
                              econom: { bg: '#9ca3af', text: '#ffffff' },
                              comfort: { bg: '#fbbf24', text: '#000000' },
                              optimum: { bg: '#10b981', text: '#ffffff' },
                              premium: { bg: '#0ea5e9', text: '#ffffff' },
                              luxury: { bg: '#8b5cf6', text: '#ffffff' },
                            };
                            const segColor = colors[cfg.key] || { bg: '#f3f4f6', text: '#9ca3af' };

                            let priceText = '';
                            if (almatyPriceForRanges) {
                              if (cfg.key === 'econom' && Number.isFinite(almatyPriceForRanges.econom)) {
                                priceText = `до ${Number(almatyPriceForRanges.econom).toLocaleString('ru-RU')} ₸`;
                              }
                              if (cfg.key === 'comfort' && Number.isFinite(almatyPriceForRanges.comfort)) {
                                priceText = `до ${Number(almatyPriceForRanges.comfort).toLocaleString('ru-RU')} ₸`;
                              }
                              if (cfg.key === 'optimum' && Number.isFinite(almatyPriceForRanges.optimum)) {
                                priceText = `до ${Number(almatyPriceForRanges.optimum).toLocaleString('ru-RU')} ₸`;
                              }
                              if (cfg.key === 'premium' && Number.isFinite(almatyPriceForRanges.premium)) {
                                priceText = `до ${Number(almatyPriceForRanges.premium).toLocaleString('ru-RU')} ₸`;
                              }
                              if (cfg.key === 'luxury' && Number.isFinite(almatyPriceForRanges.luxury)) {
                                priceText = `от ${Number(almatyPriceForRanges.luxury).toLocaleString('ru-RU')} ₸`;
                              }
                            }

                            return (
                              <div
                                key={cfg.key}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'space-between',
                                  width: '100%'
                                }}
                              >
                                <div
                                  style={{
                                    backgroundColor: segColor.bg,
                                    borderRadius: '20px',
                                    padding: '8px 16px',
                                    color: segColor.text,
                                    fontSize: '14px',
                                    fontWeight: '600',
                                    minWidth: '100px',
                                    textAlign: 'center'
                                  }}
                                >
                                  {cfg.name}
                                </div>
                                
                                <div style={{ 
                                  fontSize: '14px', 
                                  fontWeight: '500',
                                  color: '#000000',
                                  textAlign: 'right',
                                  marginLeft: '12px'
                                }}>
                                  {priceText}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {analyticsRow && nicheStatuses?.[analyticsRow.id] && (
                      <div style={{ marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px', padding: '8px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
                        <div
                          style={{
                            width: '12px',
                            height: '12px',
                            borderRadius: '50%',
                            backgroundColor:
                              nicheStatuses[analyticsRow.id].status === 'green' ? '#22c55e' :
                              nicheStatuses[analyticsRow.id].status === 'yellow' ? '#eab308' :
                              '#ef4444',
                          }}
                        />
                        <span style={{ fontSize: '13px', fontWeight: '500' }}>
                          {nicheStatuses[analyticsRow.id].status === 'green' ? 'Свободно' :
                           nicheStatuses[analyticsRow.id].status === 'yellow' ? 'Вытеснение' : 'Активно'}
                        </span>
                        <span style={{ fontSize: '15px', fontWeight: 'bold', marginLeft: 'auto' }}>
                          {nicheStatuses[analyticsRow.id].price.toLocaleString('ru-RU')} ₸
                        </span>
                      </div>
                    )}

                    {analyticsRow && (
                      <div style={{ 
                        backgroundColor: '#f9fafb', 
                        borderRadius: '12px', 
                        padding: '16px',
                        marginBottom: '16px'
                      }}>
                        <div style={{ 
                          display: 'grid', 
                          gridTemplateColumns: '1fr 1fr 1fr 1fr', 
                          gap: '8px',
                          marginBottom: '12px',
                          fontSize: '12px',
                          color: '#6b7280',
                          textAlign: 'center'
                        }}>
                          <div>1 км</div>
                          <div>3 км</div>
                          <div>6 км</div>
                          <div>City</div>
                        </div>

                        <div style={{ 
                          display: 'grid', 
                          gridTemplateColumns: '1fr 1fr 1fr 1fr', 
                          gap: '8px',
                          fontSize: '14px',
                          fontWeight: '500',
                          textAlign: 'center'
                        }}>
                          <div>{analyticsRow.views1km?.toLocaleString('ru-RU') ?? '0'}</div>
                          <div>{analyticsRow.views3km?.toLocaleString('ru-RU') ?? '0'}</div>
                          <div>{analyticsRow.views6km?.toLocaleString('ru-RU') ?? '0'}</div>
                          <div>{analyticsRow.viewsCity?.toLocaleString('ru-RU') ?? '0'}</div>
                        </div>
                      </div>
                    )}

                    <div style={{ 
                      backgroundColor: '#ffffff', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '12px', 
                      padding: '16px',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}>
                      <span style={{ fontSize: '14px', color: '#374151' }}>WhatsApp переходы</span>
                      <span style={{ fontSize: '20px', fontWeight: 'bold', color: '#2563eb' }}>
                        {analyticsRow?.whatsappClicks?.toLocaleString('ru-RU') ?? '0'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'profile' && (
                <div>
                  <h2 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '12px' }}>Мой профиль</h2>
                  <div style={{ border: '1px solid #e5e7eb', borderRadius: '8px', padding: '16px', backgroundColor: '#ffffff' }}>
                    <div style={{ marginBottom: '16px' }}>
                      <div style={{ fontSize: '12px', fontWeight: '500', color: '#374151', marginBottom: '4px' }}>ФИО</div>
                      <input
                        type="text"
                        value={profileFullName}
                        onChange={(e) => setProfileFullName(e.target.value)}
                        style={{
                          width: '100%',
                          height: '36px',
                          border: '1px solid #d1d5db',
                          borderRadius: '4px',
                          padding: '0 8px',
                          fontSize: '14px',
                          boxSizing: 'border-box'
                        }}
                        placeholder="Введите ФИО"
                      />
                      <div style={{ marginTop: '8px' }}>
                        <button style={unifiedButtonStyle} onClick={handleSaveProfile}>Save</button>
                      </div>
                    </div>

                    <div style={{ marginBottom: '16px' }}>
                      <div style={{ fontSize: '12px', fontWeight: '500', color: '#374151', marginBottom: '4px' }}>Фото</div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <img
                          src={profilePhotoUrl}
                          alt="Doctor"
                          style={{ width: '48px', height: '48px', borderRadius: '4px', objectFit: 'cover' }}
                        />
                        <div style={{ display: 'flex', gap: '8px' }}>
                          <input 
                            type="file" 
                            accept="image/*" 
                            onChange={(e) => handleDocumentUpload(e, 'profile', (url) => setProfilePhotoUrl(url))} 
                            style={{ display: 'none' }} 
                            id="mobile-profile-photo-input"
                          />
                          <label htmlFor="mobile-profile-photo-input" style={unifiedButtonStyle}>
                            <span>Upload</span>
                          </label>
                          <button onClick={() => setProfilePhotoUrl(doctorPhotoUrl)} style={unifiedButtonStyle}>Delete</button>
                        </div>
                      </div>
                    </div>

                    <div style={{ marginBottom: '16px' }}>
                      <div style={{ fontSize: '12px', fontWeight: '500', color: '#374151', marginBottom: '4px' }}>WhatsApp</div>
                      <input
                        type="tel"
                        value={profileWhatsapp}
                        onChange={(e) => setProfileWhatsapp(e.target.value)}
                        style={{
                          width: '100%',
                          height: '36px',
                          border: '1px solid #d1d5db',
                          borderRadius: '4px',
                          padding: '0 8px',
                          fontSize: '14px',
                          boxSizing: 'border-box'
                        }}
                        placeholder="+7 (___) ___ __-__"
                      />
                      <div style={{ marginTop: '8px' }}>
                        <button style={unifiedButtonStyle} onClick={handleSaveProfile}>Save</button>
                      </div>
                    </div>

                    <div style={{ marginBottom: '16px' }}>
                      <div style={{ fontSize: '12px', fontWeight: '500', color: '#374151', marginBottom: '4px' }}>Адрес</div>
                      <input
                        type="text"
                        value={profileAddress}
                        onChange={(e) => setProfileAddress(e.target.value)}
                        style={{
                          width: '100%',
                          height: '36px',
                          border: '1px solid #d1d5db',
                          borderRadius: '4px',
                          padding: '0 8px',
                          fontSize: '14px',
                          boxSizing: 'border-box'
                        }}
                        placeholder="Введите адрес оказания услуг"
                      />
                      <div style={{ marginTop: '8px' }}>
                        <button style={unifiedButtonStyle} onClick={handleSaveProfile}>Save</button>
                      </div>
                    </div>

                    <div>
                      <h3 style={{ fontSize: '13px', fontWeight: '500', marginBottom: '8px' }}>ҚҰЖАТТАР / ДОКУМЕНТЫ</h3>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                        <div>
                          <div style={{ fontSize: '12px', color: '#374151', marginBottom: '4px' }}>Сертификат</div>
                          <div style={{ display: 'flex', gap: '8px' }}>
                            <input 
                              type="file" 
                              accept="image/*,.pdf" 
                              onChange={(e) => handleDocumentUpload(e, 'certificate')} 
                              style={{ display: 'none' }} 
                              id="mobile-certificate-input"
                            />
                            <label htmlFor="mobile-certificate-input" style={unifiedButtonStyle}>
                              <span>Upload</span>
                            </label>
                            <button onClick={() => handleDocumentDelete(setCertificate, DOCUMENT_KEYS.certificate)} style={unifiedButtonStyle}>Delete</button>
                          </div>
                          {certificate && <div style={{ fontSize: '11px', color: '#059669', marginTop: '2px' }}>{certificate.name}</div>}
                        </div>
                        <div>
                          <div style={{ fontSize: '12px', color: '#374151', marginBottom: '4px' }}>Категория</div>
                          <div style={{ display: 'flex', gap: '8px' }}>
                            <input 
                              type="file" 
                              accept="image/*,.pdf" 
                              onChange={(e) => handleDocumentUpload(e, 'category')} 
                              style={{ display: 'none' }} 
                              id="mobile-category-input"
                            />
                            <label htmlFor="mobile-category-input" style={unifiedButtonStyle}>
                              <span>Upload</span>
                            </label>
                            <button onClick={() => handleDocumentDelete(setCategory, DOCUMENT_KEYS.category)} style={unifiedButtonStyle}>Delete</button>
                          </div>
                          {category && <div style={{ fontSize: '11px', color: '#059669', marginTop: '2px' }}>{category.name}</div>}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'reports' && (
                <div>
                  <h2 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '12px' }}>Отчёты</h2>
                  <p style={{ color: '#6b7280', fontSize: '14px' }}>Нет данных для отображения</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}