import { NextResponse } from 'next/server';
import * as XLSX from 'xlsx';
import path from 'path';
import fs from 'fs';

export async function GET() {
  const pricesFilePath = path.join(process.cwd(), 'data-src', 'DentaPrice_Almaty_Prices.xlsx');
  const mapFilePath = path.join(process.cwd(), 'data-src', 'service_id_map.json');
  
  if (!fs.existsSync(pricesFilePath)) {
    console.error('[API /prices/almaty] File not found:', pricesFilePath);
    return NextResponse.json([]);
  }
  
  if (!fs.existsSync(mapFilePath)) {
    console.error('[API /prices/almaty] File not found:', mapFilePath);
    return NextResponse.json([]);
  }

  try {
    const pricesBuffer = fs.readFileSync(pricesFilePath);
    const pricesWorkbook = XLSX.read(pricesBuffer, { type: 'buffer' });
    const pricesSheet = pricesWorkbook.Sheets[pricesWorkbook.SheetNames[0]];
    const priceRows = XLSX.utils.sheet_to_json(pricesSheet, { header: 1 });

    const mapFile = fs.readFileSync(mapFilePath, 'utf-8');
    const serviceMap = JSON.parse(mapFile);

    const nameToId: Record<string, string> = {};
    for (const item of serviceMap) {
      nameToId[item.serviceNameRU] = item.serviceId;
    }

    const extractNumber = (val: unknown): number | null => {
      if (!val || typeof val !== 'string') return null;
      const match = val.match(/(\d[\d\s]*)/g);
      if (!match) return null;
      const nums = match.map(s => parseInt(s.replace(/\s/g, ''), 10));
      return nums[nums.length - 1];
    };

    const result = [];
    for (let i = 1; i < priceRows.length; i++) {
      const row = priceRows[i] as any[];
      const serviceName = row[1]?.toString().trim();
      if (!serviceName) continue;
      
      const serviceId = nameToId[serviceName];
      if (!serviceId) continue;

      const econom = extractNumber(row[4]);
      const comfort = extractNumber(row[5]);
      const optimum = extractNumber(row[6]);
      const premium = extractNumber(row[7]);
      const luxury = extractNumber(row[8]);

      result.push({
        serviceId,
        econom,
        comfort,
        optimum,
        premium,
        luxury
      });
    }

    // Лог для o5
    const o5 = result.find(r => r.serviceId === 'o5');
    console.log('[API] o5 data:', JSON.stringify(o5, null, 2));

    return NextResponse.json(result);
  } catch (error) {
    console.error('[API /prices/almaty] Error:', error);
    return NextResponse.json([]);
  }
}