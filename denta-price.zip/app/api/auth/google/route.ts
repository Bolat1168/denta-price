import { NextResponse } from 'next/server';
import { OAuth2Client } from 'google-auth-library';
import fs from 'fs/promises';
import path from 'path';

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
const DENTISTS_FILE = path.join(process.cwd(), 'data-src', 'dentists.json');

async function readDentists() {
  try {
    const data = await fs.readFile(DENTISTS_FILE, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

async function writeDentists(dentists: any[]) {
  await fs.writeFile(DENTISTS_FILE, JSON.stringify(dentists, null, 2));
}

export async function POST(req: Request) {
  try {
    const { accessToken } = await req.json();
    const idToken = accessToken; // Google One Tap передаёт id_token

    // Верификация ID токена
    const ticket = await client.verifyIdToken({
      idToken: idToken,
      audience: process.env.GOOGLE_CLIENT_ID,
    });
    const payload = ticket.getPayload();
    if (!payload) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const { sub: googleId, name, email, picture } = payload;

    const dentists = await readDentists();
    let dentist = dentists.find((d: any) => d.googleId === googleId || d.email === email);

    if (!dentist) {
      const newId = `doctor-${Date.now()}`;
      dentist = {
        id: newId,
        googleId,
        email,
        fullName: name,
        photoUrl: picture || '/images/doctors/doctor1.png',
        whatsapp: '',
        address: '',
        services: [],
        createdAt: new Date().toISOString(),
      };
      dentists.push(dentist);
      await writeDentists(dentists);
    }

    return NextResponse.json({ dentistId: dentist.id });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}